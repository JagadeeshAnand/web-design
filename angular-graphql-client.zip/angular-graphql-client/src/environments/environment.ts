// The file contents for the current environment will overwrite these during build.
// The build system defaults to the dev environment which uses `environment.ts`, but if you do
// `ng build --env=prod` then `environment.prod.ts` will be used instead.
// The list of which env maps to which file can be found in `.angular-cli.json`.

export const environment = {
  production: false,
  url: 'https://kubili-house-store.myshopify.com/api/graphql',
  shopifyaccesstoken: 'efb1aa4ca2de89c40a70f2d2a4dc5c24'
};
