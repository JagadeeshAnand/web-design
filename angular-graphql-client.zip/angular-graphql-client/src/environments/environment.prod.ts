export const environment = {
  production: true,
  url: 'https://kubili-house-store.myshopify.com/api/graphql',
  shopifyaccesstoken: 'efb1aa4ca2de89c40a70f2d2a4dc5c24'
};
