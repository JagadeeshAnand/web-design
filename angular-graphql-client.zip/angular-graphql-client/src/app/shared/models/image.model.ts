export class Image{
    altText: String;
    id: string;
    src: string;
}