import { Component, AfterViewInit, ViewEncapsulation } from '@angular/core'; 
declare var jQuery: any;
@Component({
  selector: 'contact', 
  templateUrl: './contact.html',
  styleUrls: ['./contact.css']
})
export class ContactComponent {
  public scrollbarOptions = { axis: 'y', theme: 'minimal-dark', scrollInertia: 300 };
}
