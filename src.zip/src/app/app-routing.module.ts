import { NgModule, ModuleWithProviders } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HowItWorksComponent } from './how-it-works/how-it-works.component';
import { HomeComponent } from './home/home/home.component';
import { HowWeThinkComponent } from './how-we-think/how-we-think.component';
import { WhyUsComponent } from './why-us/why-us.component';
import { WhatWeOfferComponent } from './what-we-offer/what-we-offer.component';
import { sideMenuhwtComponent } from './sidebar/sideMenu-hwt/sideMenu-hwt.component';
import { sideMenuhiwComponent } from './sidebar/sideMenu-hiw/sideMenu-hiw.component';
import { sideMenuwwoComponent } from './sidebar/sideMenu-wwo/sideMenu-wwo.component';
import { sideMenuwuComponent } from './sidebar/sideMenu-wu/sideMenu-wu.component';
import { ContactComponent } from './contact/contact';
import { AboutComponent } from './about/about';
import { PressComponent } from './press/press';
//import { LoginComponent } from './login/login';

const routes: Routes = [
  {
    path: '',
    redirectTo: 'home',
    pathMatch: 'full'
  },
  //{
  //  path: 'howWeThink',
  //  component: HowWeThinkComponent,
  //  //outlet: 'menupopup'
  //},
  //{
  //  path: 'howItWorks',
  //  component: HowItWorksComponent,
  // // outlet: 'menupopup'
  //},
  //{
  //  path: 'whatWeOffer',
  //  component: WhatWeOfferComponent,
  //  //outlet: 'menupopup'
  //},
  //{
  //  path: 'whyUs',
  //  component: WhyUsComponent,
  //  //outlet: 'menupopup'
  //},
  {
    path: 'how_we_think',
    component: sideMenuhwtComponent,
    //outlet: 'menupopup'
  },
  {
    path: 'how_it_works',
    component: sideMenuhiwComponent,
    //outlet: 'menupopup'
  },
  {
    path: 'what_we_offer',
    component: sideMenuwwoComponent,
    //outlet: 'menupopup'
  },
  {
    path: 'why_us',
    component: sideMenuwuComponent,
    //outlet: 'menupopup'
  },
  {
    path: 'about',
    component: AboutComponent,
    //outlet: 'menupopup'
  },
  {
    path: 'contact',
    component: ContactComponent,
    //outlet: 'menupopup'
  },
  {
    path: 'press',
    component: PressComponent,
    //outlet: 'menupopup'
  },
  // {
  //   path: 'login',
  //   component: LoginComponent 
  // },
  {
    path: 'home',
    component: HomeComponent  
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes, {useHash: false})],
  exports: [RouterModule]
})
export class AppRoutingModule { }
// export const routingModule: ModuleWithProviders = RouterModule.forRoot(routes);
