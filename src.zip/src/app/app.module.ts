import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NgModule, enableProdMode } from '@angular/core';
import { AngularFontAwesomeModule } from 'angular-font-awesome';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { SidebarComponent } from './sidebar/sidebar.component';
import { HowItWorksComponent } from './how-it-works/how-it-works.component'; 
import { HowWeThinkComponent } from './how-we-think/how-we-think.component';
import { WhatWeOfferComponent } from './what-we-offer/what-we-offer.component';
import { WhyUsComponent } from './why-us/why-us.component';
import { HomeModule } from './home/home.module';
import { NavMenuComponent } from './nav-menu/nav-menu.component';
import { sideMenuhwtComponent } from './sidebar/sideMenu-hwt/sideMenu-hwt.component';
import { sideMenuhiwComponent } from './sidebar/sideMenu-hiw/sideMenu-hiw.component';
import { sideMenuwwoComponent } from './sidebar/sideMenu-wwo/sideMenu-wwo.component';
import { sideMenuwuComponent } from './sidebar/sideMenu-wu/sideMenu-wu.component';
import { ConstructionComponent } from './construction/construction';
import { UrlSerializer } from '@angular/router';
import { StandardUrlSerializer } from './StandardUrlSerializer';
import { MalihuScrollbarModule } from 'ngx-malihu-scrollbar';
import { AboutComponent } from './about/about';
import { ContactComponent } from './contact/contact';
import { PressComponent } from './press/press';
import { LoginComponent } from './login/login';

import {MaterialModule} from './material-module';

@NgModule({
  declarations: [
    AppComponent,
    SidebarComponent, 
    HowItWorksComponent,
    HowWeThinkComponent,
    WhatWeOfferComponent,
    WhyUsComponent,
    NavMenuComponent,
    ConstructionComponent,
    sideMenuhwtComponent,
    sideMenuhiwComponent,
    sideMenuwwoComponent,
    sideMenuwuComponent,
    AboutComponent, ContactComponent, PressComponent, LoginComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,MaterialModule,
    AngularFontAwesomeModule, HomeModule, MalihuScrollbarModule.forRoot(),
  ],
  providers: [ 
   // { provide: UrlSerializer, useClass: StandardUrlSerializer }
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
