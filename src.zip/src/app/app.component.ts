import { Component, AfterViewInit } from '@angular/core';
import { SidebarService } from './sidebar/sidebar.service';

declare var $: any;
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements AfterViewInit { 
  constructor(public sidebarservice: SidebarService) { }
  toggleSidebar() {
    if (!this.sidebarservice.getSidebarState()) { this.sidebarservice.toggled = true;  }
    else { this.sidebarservice.toggled = false;  }
    //$("#open-sidebar").click();
  }
  toggleBackgroundImage() {
    this.sidebarservice.hasBackgroundImage = !this.sidebarservice.hasBackgroundImage;
  }
  getSideBarState() {
    return this.sidebarservice.getSidebarState();
  }

  hideSidebar() {
    this.sidebarservice.setSidebarState(true);
  }
  ngAfterViewInit() {
  }
}
