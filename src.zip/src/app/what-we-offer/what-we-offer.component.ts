import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-what-we-offer',
  templateUrl: './what-we-offer.component.html',
  styleUrls: ['./what-we-offer.component.scss']
})
export class WhatWeOfferComponent implements OnInit {

  constructor(private router: Router) { }

  ngOnInit() {
  }
  closePopup() {
    this.router.navigate([{ outlets: { menupopup: null }}]);
  }
}
