import { Component, OnInit, AfterViewInit, AfterViewChecked, AfterContentInit, DoCheck, HostListener } from '@angular/core';
import { trigger, state, style, transition, animate } from '@angular/animations';
import { SidebarService } from './sidebar.service';
// import { MenusService } from './menus.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-sidebar',
  templateUrl: './sidebar.component.html',
  styleUrls: ['./sidebar.component.scss'],
  animations: [
    trigger('slide', [
      state('up', style({ height: 0 })),
      state('down', style({ height: '*' })),
      transition('up <=> down', animate(200))
    ])
  ]
})
export class SidebarComponent implements OnInit, AfterViewInit {
  menus = []; public href: string = "";
  public isSidebarExpanded = false;
  public windowWidth: any;
  public scrollbarOptions = { axis: 'y', theme: 'minimal', scrollInertia: 300 };

  constructor(public sidebarservice: SidebarService, private router: Router) {
    this.menus = sidebarservice.getMenuList();
  }

  toggleSidebar() { // Toggle sidebar 
    this.sidebarservice.setSidebarState(!this.sidebarservice.getSidebarState());
    if (!this.sidebarservice.getSidebarState()) {
      this.isSidebarExpanded = false;
    } else {
      this.isSidebarExpanded = true;
    }
  }

  ngOnInit() {
    this.windowWidth = window.innerWidth;
    this.href = this.router.url;
  }

  getSideBarState() {
    return this.sidebarservice.getSidebarState();
  }
  mobileDevice() {

  }
  toggle(currentMenu) {

    if (currentMenu.type === 'dropdown') {
      this.menus.forEach(element => {
        if (element === currentMenu) {
          currentMenu.active = !currentMenu.active;
        } else {
          element.active = false;
        }
      });
    }

    ///// mobile width
    if (this.windowWidth <= 508) {
      this.toggleSidebar();
    }

  }

  @HostListener('window:resize', ['$event'])
  onResize(event) {
    this.windowWidth = event.target.innerWidth 
  }
   
  hasBackgroundImage() {
    return this.sidebarservice.hasBackgroundImage;
  }

  closePopup() {
    //this.router.navigate([{ outlets: { menupopup: null } }]);
    this.router.navigate(['/']);
  }
  ngAfterViewInit() {
    let MenuName = this.menus.map(x => x.name);  
    MenuName.push('about');
    MenuName.push('contact');
    MenuName.push('press');
    MenuName.push('login');
    let locpath = window.location.pathname.toString().split('/'); console.log(locpath[locpath.length - 1]);
    if (MenuName.indexOf(locpath[locpath.length - 1]) !== -1) {
      (async () => {
        await this.delay(0);
        this.toggleSidebar();
      })();
    }
  }
  delay(ms: number) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }
}
