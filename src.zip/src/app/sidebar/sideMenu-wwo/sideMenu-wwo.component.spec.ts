import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { sideMenuwwoComponent } from './sideMenu-wwo.component';

describe('sideMenuwwoComponent', () => {
  let component: sideMenuwwoComponent;
  let fixture: ComponentFixture<sideMenuwwoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [sideMenuwwoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(sideMenuwwoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
