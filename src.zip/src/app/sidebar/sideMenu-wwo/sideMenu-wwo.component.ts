import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-wwo',
  templateUrl: './sideMenu-wwo.component.html',
  styleUrls: ['./sideMenu-wwo.component.scss']
})
export class sideMenuwwoComponent implements OnInit {
  public scrollbarOptions = { axis: 'y', theme: 'minimal-dark', scrollInertia: 300};
  constructor(private router: Router) { }

  ngOnInit() {
  }
  closePopup() {
    this.router.navigate([{ outlets: { menupopup: null }}]);
  }
}
