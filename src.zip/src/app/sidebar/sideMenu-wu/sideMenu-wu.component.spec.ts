import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { sideMenuwuComponent } from './sideMenu-wu.component';

describe('WhyUsComponent', () => {
  let component: sideMenuwuComponent;
  let fixture: ComponentFixture<sideMenuwuComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [sideMenuwuComponent ]
    })
    .compileComponents();
  }));
  beforeEach(() => {
    fixture = TestBed.createComponent(sideMenuwuComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
