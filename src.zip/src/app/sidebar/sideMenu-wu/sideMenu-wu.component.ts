import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-wu',
  templateUrl: './sideMenu-wu.component.html',
  styleUrls: ['./sideMenu-wu.component.scss']
})
export class sideMenuwuComponent implements OnInit {
  public scrollbarOptions = { axis: 'y', theme: 'minimal-dark', scrollInertia: 300 };
  constructor(private router: Router) { }

  ngOnInit() {
  }
  closePopup() {
    this.router.navigate([{ outlets: { menupopup: null }}]);
  }
}
