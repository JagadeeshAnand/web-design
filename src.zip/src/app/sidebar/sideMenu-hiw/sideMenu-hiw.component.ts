import { Component, OnInit, Output } from '@angular/core';
import { Router } from '@angular/router';
import * as d3 from 'd3'; 
@Component({
  selector: 'app-hiw',
  templateUrl: './sideMenu-hiw.component.html',
  styleUrls: ['./sideMenu-hiw.component.scss']
})
export class sideMenuhiwComponent implements OnInit {
  public scrollbarOptions = { axis: 'y', theme: 'minimal-dark', scrollInertia: 300 };
  @Output('tabSel') tabSel: any;
  @Output('indSel') indSel: any;
  Seltab: string = "0";
  indexes: any = [
    {
      name: 'Alpha Building Blocks U.S. Small-Cap Allocation Index',
      ticker: 'URSRT',
      code: 4
    },
    {
      name: 'Alpha Building Blocks U.S. Large-Cap Allocation Index',
      ticker: 'URLRT',
      code: 9
    }
  ];
  SelIndex: string = this.indexes[0].code;
  selTick: string = this.indexes[0].ticker;
  selName: string = this.indexes[0].name;
  constructor(private router: Router) { }

  ngOnInit() {
  }
  tabChanged(a) { 
    this.Seltab = a.index;
  }
  closePopup() {
    this.router.navigate([{ outlets: { menupopup: null }}]);
  }
  toggleFullscreen() {
    let elem = document.getElementById("dvIndex"); 
    if (!document['fullscreenElement'] && !document['mozFullScreenElement'] &&
      !document['webkitFullscreenElement'] && !document['msFullscreenElement']) {
      let methodToBeInvoked = elem.requestFullscreen ||
        elem['webkitRequestFullScreen'] || elem['mozRequestFullscreen']
        ||
        elem['msRequestFullscreen']; 
      if (methodToBeInvoked) {
        methodToBeInvoked.call(elem);
        d3.select("#btnFullscreen").attr("src", "../../assets/images/fullscreen_exit.png")
      }
    }
    else {
      try {
        if (document.exitFullscreen) {
          document.exitFullscreen();
        } else if (elem['msExitFullscreen'] || elem['mozCancelFullScreen'] || elem['webkitExitFullscreen']) {
          let methodToBeInvoked = elem['exitFullscreen'] || elem['webkitRequestFullScreen'] || elem['mozRequestFullscreen'] || elem['msRequestFullscreen']
          methodToBeInvoked.call(elem);
        }
      } catch (e) { console.log(e); }
      d3.select("#btnFullscreen").attr("src", "../../assets/images/fullscreen.png")
    }  
  } 
}
