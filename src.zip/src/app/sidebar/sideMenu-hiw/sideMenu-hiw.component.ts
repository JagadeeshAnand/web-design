import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-hiw',
  templateUrl: './sideMenu-hiw.component.html',
  styleUrls: ['./sideMenu-hiw.component.scss']
})
export class sideMenuhiwComponent implements OnInit {
  public scrollbarOptions = { axis: 'y', theme: 'minimal-dark', scrollInertia: 300 };
  constructor(private router: Router) { }

  ngOnInit() {
  }

  closePopup() {
    this.router.navigate([{ outlets: { menupopup: null }}]);
  }

}
