import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { sideMenuhiwComponent } from './sideMenu-hiw.component';

describe('sideMenuhiwComponent', () => {
  let component: sideMenuhiwComponent;
  let fixture: ComponentFixture<sideMenuhiwComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [sideMenuhiwComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(sideMenuhiwComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
