import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class SidebarService {
  toggled = false;
  _hasBackgroundImage = true;
  menus = [
    {
      title: 'How We Think',
      icon: 'fa',
      active: false,
      name:'how_we_think'
    },
    {
      title: 'How It Works',
      icon: 'fa',
      active: false,
      name: 'how_it_works'
    },
    {
      title: 'What We Offer',
      icon: 'fa',
      active: false,
      name: 'what_we_offer'
    },
    {
      title: 'Why Us',
      icon: 'fa',
      active: false,
      name: 'why_us'
    }
  ];
  constructor() { }

  toggle() {
    this.toggled = ! this.toggled;
  }

  getSidebarState() {
    return this.toggled;
  }

  setSidebarState(state: boolean) {
    this.toggled = state;
  }

  getMenuList() {
    return this.menus;
  }

  get hasBackgroundImage() {
    return this._hasBackgroundImage;
  }

  set hasBackgroundImage(hasBackgroundImage) {
    this._hasBackgroundImage = hasBackgroundImage;
  }
}
