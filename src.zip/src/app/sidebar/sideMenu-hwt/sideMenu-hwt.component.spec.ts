import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { sideMenuhwtComponent } from './sideMenu-hwt.component';

describe('HowWeThinkComponent', () => {
  let component: sideMenuhwtComponent;
  let fixture: ComponentFixture<sideMenuhwtComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [sideMenuhwtComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(sideMenuhwtComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
