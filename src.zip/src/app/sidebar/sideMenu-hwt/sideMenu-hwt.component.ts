import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-hwt',
  templateUrl: './sideMenu-hwt.component.html',
  styleUrls: ['./sideMenu-hwt.component.scss']
})
export class sideMenuhwtComponent implements OnInit {
  public scrollbarOptions = { axis: 'y', theme: 'minimal-dark', scrollInertia: 300};
  constructor(private router: Router) { }

  ngOnInit() {
  }
  closePopup() {
    this.router.navigate([{ outlets: { menupopup: null }}]);
  }
}
