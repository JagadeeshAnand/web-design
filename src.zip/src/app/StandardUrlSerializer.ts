import { DefaultUrlSerializer, UrlSerializer, UrlTree } from '@angular/router';
import { appContants } from '../app/app.contants';

export class StandardUrlSerializer implements UrlSerializer {
    private _defaultUrlSerializer: DefaultUrlSerializer = new DefaultUrlSerializer();

  parse(url: string): UrlTree {
    console.log(1);
        appContants.outlets.forEach(outletName => {
          const reg = new RegExp('/(' + outletName + ')/([^\/]*)');
        //  url = url.replace(reg, 'home/(menupopup:$2)');
          //url = url.replace(reg, 'home/(menupopup:$2)');
          //console.log(url); 
        //  url = url.replace(reg, '$1/($1:$2)');
          //console.log(url);
          var test = url.split('/');
          console.log(url);
          console.log(test);
          // url = (test[1] != undefined && test[1] != "") ? "/home(menupopup:" + test[1] + ")" : "";
          if (test.length ==2) 
            url = (test[2] != undefined && test[2] != "" && test[2] != "home") ? "/home/" + test[2] : "";
          else if (test.length == 1)
            url = (test[1] != undefined && test[1] != "" && test[1] != "home") ? "/home/" + test[1] : "";
          //console.log(url);
        }); 
        return this._defaultUrlSerializer.parse(url);
    }

  serialize(tree: UrlTree): string {
    console.log(2);
        let url = this._defaultUrlSerializer.serialize(tree);
        appContants.outlets.forEach(outletName => {
          const reg = new RegExp('\\(' + outletName + ':([^\/]*)\\)'); 
          url = url.replace(reg, '$1'); 
    });  
      return url;
    }  
}
