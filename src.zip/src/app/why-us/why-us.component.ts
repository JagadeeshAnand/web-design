import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-why-us',
  templateUrl: './why-us.component.html',
  styleUrls: ['./why-us.component.scss']
})
export class WhyUsComponent implements OnInit {

  constructor(private router: Router) { }

  ngOnInit() {
  }
  closePopup() {
    this.router.navigate([{ outlets: { menupopup: null }}]);
  }
}
