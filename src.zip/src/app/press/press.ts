import { Component, AfterViewInit, ViewEncapsulation } from '@angular/core'; 
declare var jQuery: any;
@Component({
  selector: 'press', 
  templateUrl: './press.html',
  styleUrls: ['./press.css']
})
export class PressComponent {
  public scrollbarOptions = { axis: 'y', theme: 'minimal-dark', scrollInertia: 300 };
}
