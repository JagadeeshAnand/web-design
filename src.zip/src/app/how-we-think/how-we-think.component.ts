import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-how-we-think',
  templateUrl: './how-we-think.component.html',
  styleUrls: ['./how-we-think.component.scss']
})
export class HowWeThinkComponent implements OnInit {

  constructor(private router: Router) { }

  ngOnInit() {
  }
  closePopup() {
    this.router.navigate([{ outlets: { menupopup: null }}]);
  }
}
