import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { HowWeThinkComponent } from './how-we-think.component';

describe('HowWeThinkComponent', () => {
  let component: HowWeThinkComponent;
  let fixture: ComponentFixture<HowWeThinkComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ HowWeThinkComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(HowWeThinkComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
