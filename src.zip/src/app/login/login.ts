import { Component, AfterViewInit, ViewEncapsulation } from '@angular/core'; 
declare var jQuery: any;
@Component({
  selector: 'login', 
  templateUrl: './login.html',
  styleUrls: ['./login.css']
})
export class LoginComponent {
  public scrollbarOptions = { axis: 'y', theme: 'minimal-dark', scrollInertia: 300 };
}
