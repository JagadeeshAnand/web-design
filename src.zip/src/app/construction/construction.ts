import { Component, AfterViewInit, ViewEncapsulation } from '@angular/core';
import * as d3 from 'd3';
declare var jQuery: any;
@Component({
  selector: 'Construction',
  encapsulation: ViewEncapsulation.None,
  templateUrl: './Construction.html',
  styleUrls: ['./construction.css']
})
export class ConstructionComponent implements AfterViewInit {
  LEI: number = 0;
  VIX: number = 0;
  SP: number = 0;
  Output: number = 4;
  ShowAll: boolean = true;
  tradeDt: string = "";
  indexes: any = [
    {
      name: 'Alpha Building Blocks U.S. Small-Cap Allocation Index',
      ticker: 'URSRT',
      code: 4
    },
    {
      name: 'Alpha Building Blocks U.S. Large-Cap Allocation Index',
      ticker: 'URLRT',
      code: 9
    }
  ];
  SelIndex: string = this.indexes[0].code;
  selTick: string = this.indexes[0].ticker;
  selName: string = this.indexes[0].name;
  EnableGroup() {
    d3.selectAll(".signalgrp").style("fill-opacity", "1");
    d3.selectAll(".signalgrp").style("stroke-opacity", "1");
    d3.selectAll(".Grped").style("fill-opacity", "1");
    d3.selectAll(".Grped").style("opacity", "1");
    d3.selectAll(".Grped").style("stroke-opacity", "1");
    if (!this.ShowAll) {
      d3.selectAll(".signalgrp").style("fill-opacity", "0.6");
      d3.selectAll(".signalgrp").style("stroke-opacity", "0.6");
      d3.selectAll(".Grped").style("fill-opacity", "0.6");
      d3.selectAll(".Grped").style("stroke-opacity", "0");
      d3.selectAll(".Grped").style("opacity", "0.6");

      if (this.LEI == 1) {
        d3.select("#LEI").style("fill-opacity", "1");
        d3.select("#cLEI").style("fill-opacity", "1");
        d3.select("#cLEI").style("stroke-opacity", "1");
      }
      if (this.VIX == 1) {
        d3.select("#VIX").style("fill-opacity", "1");
        d3.select("#cVIX").style("fill-opacity", "1");
        d3.select("#cVIX").style("stroke-opacity", "1");
      }
      if (this.SP == 1) {
        d3.select("#SP").style("fill-opacity", "1");
        d3.select("#cSP").style("fill-opacity", "1");
        d3.select("#cSP").style("stroke-opacity", "1");
      }


      let TotSignal: number = parseInt(this.LEI.toString()) + parseInt(this.VIX.toString()) + parseInt(this.SP.toString());
      let GroupName: string = "GroupOne";
      if (TotSignal >= 2 && this.Output == 1) {
        d3.select("#GroupOne").remove();
        this.GroupOne(d3.select("#svgContainer"));
        GroupName = "GroupOne";
      }
      else if (TotSignal == 1 && this.Output == 2) {
        d3.select("#GroupTwo").remove();
        this.GroupTwo(d3.select("#svgContainer"));
        GroupName = "GroupTwo";
      }
      else if (TotSignal == 1 && this.Output == 3) {
        d3.select("#GroupThree").remove();
        this.GroupThree(d3.select("#svgContainer"));
        GroupName = "GroupThree";
      }
      else if (TotSignal == 0 && this.Output == 3) {
        d3.select("#GroupFour").remove();
        this.GroupFour(d3.select("#svgContainer"));
        GroupName = "GroupFour";
      }
      else if (TotSignal == 0 && this.Output == 4) {
        d3.select("#GroupFive").remove();
        this.GroupFive(d3.select("#svgContainer"));
        GroupName = "GroupFive";
      }
      else if ((TotSignal == 0 || TotSignal == 1) && this.Output == 5) {
        d3.select("#GroupSix").remove();  
        this.GroupSix(d3.select("#svgContainer"));
        GroupName = "GroupSix";
      }
      d3.select("#" + GroupName).selectAll("circle").style("filter", "url(#dropshadow)")
      d3.select(".symbol1").attr("marker-end", "url(#minus)");
      d3.select(".symbol2").attr("marker-end", "url(#minus)");
      d3.select(".symbol3").attr("marker-end", "url(#minus)");
      if (this.LEI == 1)
        d3.select(".symbol1").attr("marker-end", "url(#plus)");
      if (this.VIX == 1)
        d3.select(".symbol2").attr("marker-end", "url(#plus)");
      if (this.SP == 1)
        d3.select(".symbol3").attr("marker-end", "url(#plus)");

      d3.select("#" + GroupName).selectAll('*').style("opacity", "0")
      d3.select("#" + GroupName).selectAll('*').transition()
        .each(function (d, i) { d3.select(this).transition().delay((i+3) * 200).style("opacity", "1").ease(d3.easeLinear); })
     

      //d3.select("#" + GroupName).selectAll('*')
      //.each(function (d, i) {
      //  d3.select(this).transition().delay(i * 500).style("opacity", "1");
      //  d3.select(this).transition()
      //    .attr("delay", function (d, i) { return 10000 * i })
      //    .attr("duration", function (d, i) { return 10000 * (i + 1) })
      //    .style("opacity", function (d, i) { return 0.5 }).attr("delay", function (d, i) { return 10000 * i })
      //    .attr("duration", function (d, i) { return 10000 * (i + 1) }).style("opacity", 1);
      //})

      //d3.select("#" + GroupName).selectAll('*').transition()
      //  .attr("delay", function (d, i) { return 1000 * (i+4) })
      //  .attr("duration", function (d, i) { return 1000 * (i + 8) })
      //  .attr("y", function (d, i) { return 30 * (i + 1) })
      //  .style("opacity", function (d, i) { return 1 })
        //.attr("y", function (d, i) { return 0.5 });

    }
  }
  GroupOne(svg) {
    var that = this;
    var GroupOne = svg.append("g").attr("id", "GroupOne").attr("class", "Grped")

    GroupOne.append("polyline")
      .style("stroke", "#000")
      .style("fill", "none")
      .attr("stroke-width", "2")
      .attr("stroke-dasharray", "5,5")
      .attr("points", "610,237, 695,102, 900,95")

    GroupOne.append("circle")
      .attr("r", 46)
      .attr("cx", 952)
      .attr("cy", 83)
      .attr("stroke", "#fff")
      .attr("stroke-width", "3")
      .attr("fill", "rgba(128,100,162)");

    GroupOne.append("text")
      .attr("x", 953)
      .attr("y", 79)
      .attr("dy", ".25em")
      .attr("fill", "#fff")
      .style("stroke-width", 1)
      .style("text-anchor", "middle")
      .style("font-size", "12px")
      .style("font-weight", "bold")
      .text('100% UR Top').call(that.wrap, 60, 953);

  }
  GroupTwo(svg) {
    var that = this;
    var GroupTwo = svg.append("g").attr("id", "GroupTwo").attr("class", "Grped")
    GroupTwo.append("line")
      .attr("x1", 620)
      .attr("y1", 320)
      .attr("x2", 680)
      .attr("y2", 298)
      .style("stroke", "#000")
      .attr("stroke-dasharray", "5,5")
      .attr("stroke-width", 2)
    GroupTwo.append("circle")
      .attr("r", 55)
      .attr("cx", 736)
      .attr("cy", 277)
      .attr("stroke", "#fff")
      .attr("stroke-width", "4")
      .attr("fill", "url(#GradToplow)");
    GroupTwo.append("text")
      .attr("x", 736)
      .attr("y", 278)
      .attr("dy", ".25em")
      .attr("fill", "#fff")
      .style("stroke-width", 1)
      .style("text-anchor", "middle")
      .style("font-size", "12px")
      .style("font-weight", "bold")
      .text('UR Top').call(that.wrap, 60, 736);

    GroupTwo.append("line")
      .attr("x1", 787)
      .attr("y1", 232)
      .attr("x2", 787)
      .attr("y2", 232)
      .attr("stroke-width", 1)
      .attr("class", "symbol1")
      .attr("marker-end", "url(#blueplus)");
    GroupTwo.append("polyline")
      .style("stroke", "#000")
      .style("fill", "none")
      .attr("stroke-width", "2")
      .attr("stroke-dasharray", "5,5")
      .attr("points", "815,237, 870,200,970,197")

    GroupTwo.append("circle")
      .attr("r", 46)
      .attr("cx", 1019)
      .attr("cy", 197)
      .attr("stroke", "#fff")
      .attr("stroke-width", "3")
      .attr("fill", "rgba(128,100,162)")
    GroupTwo.append("circle")
      .attr("r", 46)
      .attr("cx", 1019)
      .attr("cy", 198)
      .attr("stroke", "#fff")
      .attr("stroke-width", "3")
      .attr("fill", "rgba(148,138,84)")
      .attr("clip-path", "url(#toplowhalf)");
    GroupTwo.append("text")
      .attr("x", 1019)
      .attr("y", 175)
      .attr("dy", ".25em")
      .attr("fill", "#fff")
      .style("stroke-width", 1)
      .style("text-anchor", "middle")
      .style("font-size", "12px")
      .style("font-weight", "bold")
      .text('50% UR Top 50% UR Low Vol.').call(that.wrap, 60, 1019);

  }
  GroupThree(svg) {
    var that = this;
    var GroupThree = svg.append("g").attr("id", "GroupThree").attr("class", "Grped")
    GroupThree.append("line")
      .attr("x1", 620)
      .attr("y1", 320)
      .attr("x2", 680)
      .attr("y2", 298)
      .style("stroke", "#000")
      .attr("stroke-dasharray", "5,5")
      .attr("stroke-width", 2)

    GroupThree.append("circle")
      .attr("r", 55)
      .attr("cx", 736)
      .attr("cy", 277)
      .attr("stroke", "#fff")
      .attr("stroke-width", "4")
      .attr("fill", "url(#GradToplow)");

    GroupThree.append("text")
      .attr("x", 736)
      .attr("y", 278)
      .attr("dy", ".25em")
      .attr("fill", "#fff")
      .style("stroke-width", 1)
      .style("text-anchor", "middle")
      .style("font-size", "12px")
      .style("font-weight", "bold")
      .text('UR Top').call(that.wrap, 60, 736);

    GroupThree.append("line")
      .attr("x1", 790)
      .attr("y1", 286)
      .attr("x2", 790)
      .attr("y2", 286)
      .attr("stroke-width", 1)
      .attr("class", "symbol1")
      .attr("marker-end", "url(#blueminus)");

    GroupThree.append("polyline")
      .style("stroke", "#000")
      .style("fill", "none")
      .attr("stroke-width", "2")
      .attr("stroke-dasharray", "5,5")
      .attr("points", "818,304, 870,328, 992,325")

    GroupThree.append("circle")
      .attr("r", 46)
      .attr("cx", 1043)
      .attr("cy", 325)
      .attr("stroke", "#fff")
      .attr("stroke-width", "3")
      .attr("fill", "rgba(148,138,84)")
    GroupThree.append("text")
      .attr("x", 1048)
      .attr("y", 318)
      .attr("dy", ".25em")
      .attr("fill", "#fff")
      .style("stroke-width", 1)
      .style("text-anchor", "middle")
      .style("font-size", "12px")
      .style("font-weight", "bold")
      .text('100% UR Low Vol.').call(that.wrap, 60, 1042);
  }
  GroupFour(svg) {
    var that = this;
    var GroupFour = svg.append("g").attr("id", "GroupFour").attr("class", "Grped")
    GroupFour.append("line")
      .attr("x1", 615)
      .attr("y1", 410)
      .attr("x2", 680)
      .attr("y2", 448)
      .style("stroke", "#000")
      .attr("stroke-dasharray", "5,5")
      .attr("stroke-width", 2)


    GroupFour.append("circle")
      .attr("r", 55)
      .attr("cx", 736)
      .attr("cy", 468)
      .attr("stroke", "#fff")
      .attr("stroke-width", "2")
      .attr("fill", "#f9b278");

    GroupFour.append("text")
      .attr("x", 736)
      .attr("y", 460)
      .attr("dy", ".25em")
      .attr("fill", "#fff")
      .style("stroke-width", 1)
      .style("text-anchor", "middle")
      .style("font-size", "12px")
      .style("font-weight", "bold")
      .text('LEI Indicator').call(that.wrap, 60, 736);

    GroupFour.append("line")
      .attr("x1", 784)
      .attr("y1", 419)
      .attr("x2", 784)
      .attr("y2", 419)
      .attr("stroke-width", 1)
      .attr("class", "symbol1")
      .attr("marker-end", "url(#blueplus)");

    GroupFour.append("line")
      .attr("x1", 615)
      .attr("y1", 410)
      .attr("x2", 680)
      .attr("y2", 448)
      .style("stroke", "#000")
      .attr("stroke-dasharray", "5,5")
      .attr("stroke-width", 2)

    GroupFour.append("line")
      .attr("x1", 814)
      .attr("y1", 428)
      .attr("x2", 843)
      .attr("y2", 418)
      .style("stroke", "#000")
      .attr("stroke-dasharray", "5,5")
      .attr("stroke-width", 2)



    GroupFour.append("circle")
      .attr("r", 42)
      .attr("cx", 885)
      .attr("cy", 414)
      .attr("stroke", "#fff")
      .attr("stroke-width", "3")
      .attr("fill", "url(#GradlowCash)");

    GroupFour.append("text")
      .attr("x", 885)
      .attr("y", 410)
      .attr("dy", ".25em")
      .attr("fill", "#fff")
      .style("stroke-width", 1)
      .style("text-anchor", "middle")
      .style("font-size", "12px")
      .style("font-weight", "bold")
      .text('UR Low Vol.').call(that.wrap, 60, 885);

    GroupFour.append("line")
      .attr("x1", 910)
      .attr("y1", 357)
      .attr("x2", 910)
      .attr("y2", 357)
      .attr("stroke-width", 1)
      .attr("class", "symbol1")
      .attr("marker-end", "url(#blueplus)");

    GroupFour.append("polyline")
      .style("stroke", "#000")
      .style("fill", "none")
      .attr("stroke-width", "2")
      .attr("stroke-dasharray", "5,5")
      .attr("points", "936,354, 955,328, 992,325")

    GroupFour.append("circle")
      .attr("r", 46)
      .attr("cx", 1043)
      .attr("cy", 325)
      .attr("stroke", "#fff")
      .attr("stroke-width", "3")
      .attr("fill", "rgba(148,138,84)")
    GroupFour.append("text")
      .attr("x", 1048)
      .attr("y", 318)
      .attr("dy", ".25em")
      .attr("fill", "#fff")
      .style("stroke-width", 1)
      .style("text-anchor", "middle")
      .style("font-size", "12px")
      .style("font-weight", "bold")
      .text('100% UR Low Vol.').call(that.wrap, 60, 1042);

  }
  GroupFive(svg) {
    var that = this;
    var GroupFive = svg.append("g").attr("id", "GroupFive").attr("class", "Grped")
    GroupFive.append("line")
      .attr("x1", 615)
      .attr("y1", 410)
      .attr("x2", 680)
      .attr("y2", 448)
      .style("stroke", "#000")
      .attr("stroke-dasharray", "5,5")
      .attr("stroke-width", 2)


    GroupFive.append("circle")
      .attr("r", 55)
      .attr("cx", 736)
      .attr("cy", 468)
      .attr("stroke", "#fff")
      .attr("stroke-width", "2")
      .attr("fill", "#f9b278");

    GroupFive.append("text")
      .attr("x", 736)
      .attr("y", 460)
      .attr("dy", ".25em")
      .attr("fill", "#fff")
      .style("stroke-width", 1)
      .style("text-anchor", "middle")
      .style("font-size", "12px")
      .style("font-weight", "bold")
      .text('LEI Indicator').call(that.wrap, 60, 736);

    GroupFive.append("line")
      .attr("x1", 784)
      .attr("y1", 419)
      .attr("x2", 784)
      .attr("y2", 419)
      .attr("stroke-width", 1)
      .attr("class", "symbol1")
      .attr("marker-end", "url(#blueplus)");

    GroupFive.append("line")
      .attr("x1", 615)
      .attr("y1", 410)
      .attr("x2", 680)
      .attr("y2", 448)
      .style("stroke", "#000")
      .attr("stroke-dasharray", "5,5")
      .attr("stroke-width", 2)

    GroupFive.append("line")
      .attr("x1", 814)
      .attr("y1", 428)
      .attr("x2", 843)
      .attr("y2", 418)
      .style("stroke", "#000")
      .attr("stroke-dasharray", "5,5")
      .attr("stroke-width", 2)



    GroupFive.append("circle")
      .attr("r", 42)
      .attr("cx", 885)
      .attr("cy", 414)
      .attr("stroke", "#fff")
      .attr("stroke-width", "3")
      .attr("fill", "url(#GradlowCash)");

    GroupFive.append("text")
      .attr("x", 885)
      .attr("y", 410)
      .attr("dy", ".25em")
      .attr("fill", "#fff")
      .style("stroke-width", 1)
      .style("text-anchor", "middle")
      .style("font-size", "12px")
      .style("font-weight", "bold")
      .text('UR Low Vol.').call(that.wrap, 60, 885);


    GroupFive.append("line")
      .attr("x1", 926)
      .attr("y1", 418)
      .attr("x2", 926)
      .attr("y2", 418)
      .attr("stroke-width", 1)
      .attr("class", "symbol1")
      .attr("marker-end", "url(#blueminus)");
    GroupFive.append("line")
      .attr("x1", 955)
      .attr("y1", 438)
      .attr("x2", 970)
      .attr("y2", 445)
      .style("stroke", "#000")
      .attr("stroke-dasharray", "5,5")
      .attr("stroke-width", 2)
    GroupFive.append("circle")
      .attr("r", 46)
      .attr("cx", 1019)
      .attr("cy", 454)
      .attr("stroke", "#fff")
      .attr("stroke-width", "3")
      .attr("fill", "rgba(148,138,84)")
    GroupFive.append("circle")
      .attr("r", 46)
      .attr("cx", 1019)
      .attr("cy", 454)
      .attr("stroke", "#fff")
      .attr("stroke-width", "3")
      .attr("fill", "rgba(166,166,166)")
      .attr("clip-path", "url(#lowcashhalf)");
    GroupFive.append("text")
      .attr("x", 1019)
      .attr("y", 431)
      .attr("dy", ".25em")
      .attr("fill", "#fff")
      .style("stroke-width", 1)
      .style("text-anchor", "middle")
      .style("font-size", "12px")
      .style("font-weight", "bold")
      .text('50% UR Low Vol. 50% Cash').call(that.wrap, 60, 1019);
  }
  GroupSix(svg) {
    var that = this;
    var GroupSix = svg.append("g").attr("id", "GroupSix").attr("class", "Grped")

    GroupSix.append("line")
      .attr("x1", 615)
      .attr("y1", 410)
      .attr("x2", 680)
      .attr("y2", 448)
      .style("stroke", "#000")
      .attr("stroke-dasharray", "5,5")
      .attr("stroke-width", 2)

    GroupSix.append("circle")
      .attr("r", 55)
      .attr("cx", 736)
      .attr("cy", 468)
      .attr("stroke", "#fff")
      .attr("stroke-width", "2")
      .attr("fill", "#f9b278");

    GroupSix.append("text")
      .attr("x", 736)
      .attr("y", 460)
      .attr("dy", ".25em")
      .attr("fill", "#fff")
      .style("stroke-width", 1)
      .style("text-anchor", "middle")
      .style("font-size", "12px")
      .style("font-weight", "bold")
      .text('LEI Indicator').call(that.wrap, 60, 736);

    GroupSix.append("line")
      .attr("x1", 778)
      .attr("y1", 500)
      .attr("x2", 778)
      .attr("y2", 500)
      .attr("stroke-width", 1)
      .attr("class", "symbol1")
      .attr("marker-end", "url(#blueminus)");

    GroupSix.append("polyline")
      .style("stroke", "#000")
      .style("fill", "none")
      .attr("stroke-width", "2")
      .attr("stroke-dasharray", "5,5")
      .attr("points", "806,526, 870,564, 898,563")

    GroupSix.append("circle")
      .attr("r", 46)
      .attr("cx", 948)
      .attr("cy", 569)
      .attr("stroke", "#fff")
      .attr("stroke-width", "3")
      .attr("fill", "rgba(166,166,166)")
    GroupSix.append("text")
      .attr("x", 948)
      .attr("y", 560)
      .attr("dy", ".25em")
      .attr("fill", "#fff")
      .style("stroke-width", 1)
      .style("text-anchor", "middle")
      .style("font-size", "12px")
      .style("font-weight", "bold")
      .text('100% Cash').call(that.wrap, 60, 948);
  }
  ChartCreate() {
    var that = this;
    const svg = d3.select("#svgContainer");
    var Maingrp = svg.append("g").attr("id", "Maingrp").attr("x", 230).attr("y", 0).attr("width", 1100).attr("height", 950)
    Maingrp.append("rect")
      .attr("x", 230)
      .attr("y", 0)
      .attr("width", "100%")
      .attr("height", "100%")
      .style("fill", "url(#bgimage)")
      .attr("stroke", "none");

    Maingrp.append("circle")
      .attr("r", 78)
      .attr("cx", 526)
      .attr("cy", 163)
      .attr("stroke", "#fff")
      .attr("stroke-width", "4")
      .attr("class", "signalgrp")
      .attr("fill", "#00B0F0")
      .attr("id", "cLEI")
    Maingrp.append("text")
      .attr("x", 485)
      .attr("y", 130)
      .attr("dy", ".25em")
      .attr("fill", "#fff")
      .style("stroke-width", 1)
      .style("text-anchor", "left")
      .style("font-size", "13px")
      .style("font-weight", "bold")
      .attr("class", "signalgrp")
      .attr("id", "LEI")
      .text('Economic Conditions Leading Indicator').call(that.wrap, 60, 485);

    Maingrp.append("circle")
      .attr("r", 78)
      .attr("cx", 470)
      .attr("cy", 327)
      .attr("stroke", "#fff")
      .attr("stroke-width", "4")
      .attr("fill", "#00B0F0")
      .attr("class", "signalgrp")
      .attr("id", "cVIX")
    Maingrp.append("text")
      .attr("x", 430)
      .attr("y", 310)
      .attr("dy", ".25em")
      .attr("fill", "#fff")
      .style("stroke-width", 1)
      .style("text-anchor", "left")
      .style("font-size", "13px")
      .style("font-weight", "bold")
      .attr("class", "signalgrp")
      .attr("id", "VIX")
      .text('Market Sentiment VIX').call(that.wrap, 60, 430);


    Maingrp.append("circle")
      .attr("r", 78)
      .attr("cx", 525)
      .attr("cy", 494)
      .attr("stroke", "#fff")
      .attr("stroke-width", "4")
      .attr("fill", "#00B0F0")
      .attr("class", "signalgrp")
      .attr("id", "cSP")
    Maingrp.append("text")
      .attr("x", 490)
      .attr("y", 475)
      .attr("dy", ".25em")
      .attr("fill", "#fff")
      .style("stroke-width", 1)
      .style("text-anchor", "left")
      .style("font-size", "13px")
      .style("font-weight", "bold")
      .attr("class", "signalgrp")
      .attr("id", "SP")
      .text('Market Momentum S&P500').call(that.wrap, 60, 490);
    Maingrp.append("line")
      .attr("x1", 558)
      .attr("y1", 235)
      .attr("x2", 558)
      .attr("y2", 235)
      .attr("stroke-width", 1)
      .attr("class", "symbol1")
      .attr("marker-end", "url(#plus)");

    Maingrp.append("line")
      .attr("x1", 558)
      .attr("y1", 300)
      .attr("x2", 558)
      .attr("y2", 300)
      .attr("stroke-width", 1)
      .attr("class", "symbol2")
      .attr("marker-end", "url(#plus)");

    Maingrp.append("line")
      .attr("x1", 558)
      .attr("y1", 365)
      .attr("x2", 558)
      .attr("y2", 365)
      .attr("stroke-width", 1)
      .attr("class", "symbol3")
      .attr("marker-end", "url(#minus)");

    this.GroupOne(svg);
    this.GroupTwo(svg);
    this.GroupThree(svg);
    this.GroupFour(svg);
    this.GroupFive(svg);
    this.GroupSix(svg);
    this.EnableGroup();

    Maingrp.append("path")
      .attr("id", "circleArc")
      .attr("d", "M310,390a156.0242751238,200.0242751238,0,0,1,-11,-129")
      .style("fill", "none")
      .style("stroke", "none");

    Maingrp.append("text")
      .append("textPath")
      .attr("xlink:href", "#circleArc")
      .style("font-size", "18px")
      .style("font-weight", "normal")
      .attr("startOffset", "10%")
      .style("stroke", "#fff")
      .style("stroke-width", "1")
      .style("fill", "#fff")
      .text("Fed Decisions");
    var that = this;
    d3.json("http://demo.spinecapital.com/ScoresData/api/Indexes/GetRebalanceDates").then(function (data) {
      let yrCircle = that.createReblanceDates(svg, data); // Create Year circle quarter buttons

      yrCircle.selectAll(".quarter").on("click", function (e) {
        that.ShowAll = false;
        let idVal = d3.select(this).attr('id').replace("d", ""); 
        let date = idVal.slice(0, 4) + "-" + idVal.slice(4, 6) + "-" + idVal.slice(6, 8);
        that.tradeDt = date;
        that.fetchSignal();
      });
      d3.select("#d" + data[data.length - 1]).dispatch("click");
    });

  }
  fetchSignal() {
    let that = this;
    d3.json("http://demo.spinecapital.com/ScoresData/api/Indexes/GetSignalsByDate/" + that.SelIndex + "/" + that.tradeDt).then(function (signaldata) {
      that.LEI = signaldata[0].lei;
      that.VIX = signaldata[0].vix;
      that.SP = signaldata[0].sptr;
      if (signaldata[0].urltt == 1) {
        that.Output = 1;
      }
      else if (signaldata[0].urlvt == 1) {
        that.Output = 3;
      }
      else if (signaldata[0].cash == 1) {
        that.Output = 5;
      }
      else if (signaldata[0].urltt == .5 && signaldata[0].urlvt == .5) {
        that.Output = 2;
      }
      else if (signaldata[0].urlvt == .5 && signaldata[0].cash == .5) {
        that.Output = 4;
      } 
      that.EnableGroup();
    });
  }
  wrap(text, width, xval) {
    text.each(function () {
      var text = d3.select(this),
        words = text.text().split(/\s+/).reverse(),
        word,
        line = [],
        lineNumber = 0,
        lineHeight = 1.5, // ems
        y = text.attr("y"),
        dy = parseFloat(text.attr("dy")),
        tspan = text.text(null).append("tspan").attr("x", xval).attr("y", y).attr("dy", dy + "em");
      while (word = words.pop()) {
        line.push(word);
        tspan.text(line.join(" "));
        if (tspan.node().getComputedTextLength() > width) {
          line.pop();
          tspan.text(line.join(" "));
          line = [word];
          tspan = text.append("tspan").attr("x", xval).attr("y", y).attr("dy", ++lineNumber * lineHeight + dy + "em").text(word);
        }
      }
    });
  }
  createReblanceDates(obj, data) {

    var ReBaldates = d3.nest()
      .key(function (d) { return d.substring(0, 4); })
      .entries(data);

    var PI = Math.PI,
      maxTicks = ReBaldates.length,
      minTicks = 1,
      yrRadius = 600;


    var scale = d3.scaleLinear()
      .domain([minTicks, maxTicks])
      .range([1, 1 * PI]);

    var ticks = scale.ticks(maxTicks - minTicks).slice(0, -1);

    var radialAxis = obj.append('g')
      .attr("transform", "translate(650 , 300)")

    radialAxis.append('circle')
      .attr('r', yrRadius)
      .style("fill", "rgba(0,0,0,0)")
      .style("stroke-width", 1)
      .style("stroke", "#eee");

    var axialAxis = radialAxis.append('g')
      .selectAll('g')
      .data(ReBaldates)
      .enter().append('g')
      .attr('transform', function (d, i) { return 'rotate(' + (rad2deg(scale(i)) - 260) + ')translate(' + yrRadius + ', 0) ' });


    var yr = axialAxis.append('g')
      .attr('transform', function (d, i) { return 'rotate(' + (260 - rad2deg(scale(i))) + ' )' })
      .on("mouseover", onYrOver)
      .on("mouseout", onYrOut);


    yr.append('rect')
      .attr('y', '-13')
      .attr('x', '-60')
      .attr('width', '200')
      .attr('height', '26')
      .attr('fill', 'rgba(0,0,0,0)')


    yr.append('circle')
      .attr('class', 'yrBullet')
      .attr('id', function (d) { return "yb" + d.key })
      .attr("r", 3)

    yr.append('text')
      .attr('x', -15)
      .attr('y', 5)
      .style('text-anchor', 'end')
      .attr('class', 'years')
      .attr('id', function (d) { return "y" + d.key })
      .text(function (d) { return d.key });

    var yrQ = yr.append('g')
      .selectAll('g')
      .data(function (d) { return d.values })
      .enter().append('g')
      .attr("class", "quarter")
      .attr('id', function (d, i) { return "d" + d });


    yrQ.append('circle')
      .attr("cx", function (d, i) { return 25 + (30 * i) })
      .attr("r", 14).style("fill", "#fff").attr("stroke", "#ddd").attr("stroke-width", "1"); 

    yrQ.append("text")
      .attr("dx", function (d, i) { return 14 + (30 * i) })
      .attr("dy", 4)
      .style("fill", "#000")
      .style("font-size", "8px")
      .text(function (d, i) {
        var dt = d.substr(4, 2);
        //return "Q" + (dt / 3)
        //console.log(d + " == " + dt + "/" + d.substr(6, 2));
        return dt + "/" + d.substr(6, 2)
      });


    function rad2deg(angle) {
      return angle * 40;
    }

    function onYrOver(elemData) {
      d3.select(this).classed("yrOn", true);
      d3.select(this).selectAll('.quarter').transition().duration(300).attr("transform", "scale(1.2)").style('opacity', '1');
      d3.select(this).selectAll('.yrBullet').transition().duration(300).attr("transform", "scale(1.2)")
      d3.select(this).selectAll('.years').transition().duration(300).attr("transform", "scale(1.2)")
    }

    function onYrOut(elemData) {
      d3.select(this).classed("yrOn", false);
      d3.select(this).selectAll('.quarter').transition().duration(300).attr("transform", "scale(1)").style('opacity', '0');
      d3.select(this).selectAll('.yrBullet').transition().duration(300).attr("transform", "scale(1)")
      d3.select(this).selectAll('.years').transition().duration(300).attr("transform", "scale(1)")
    }

    function QuarterClk(elemData) {
      this.ChartCreate();
    }
    /*//	White arc line for years - End \\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\*/

    return yr;


  }

  toggleFullscreen() {
    let elem = document.getElementById("chart");

    //if (!document.fullscreenElement && !document.mozFullScreenElement &&
    //  !document.webkitFullscreenElement && !document.msFullscreenElement) {
    //  if (elem.requestFullscreen) {
    //    elem.requestFullscreen();
    //  } else if (elem.msRequestFullscreen) {
    //    elem.msRequestFullscreen();
    //  } else if (elem.mozRequestFullScreen) {
    //    elem.mozRequestFullScreen();
    //  } else if (elem.webkitRequestFullscreen) {
    //    elem.webkitRequestFullscreen(Element.ALLOW_KEYBOARD_INPUT);
    //  }
    //  d3.select("#btnFullscreen").attr("src", "fullscreen_exit.png")

    //} else {
    //  if (document.exitFullscreen) {
    //    document.exitFullscreen();
    //  } else if (document.msExitFullscreen) {
    //    document.msExitFullscreen();
    //  } else if (document.mozCancelFullScreen) {
    //    document.mozCancelFullScreen();
    //  } else if (document.webkitExitFullscreen) {
    //    document.webkitExitFullscreen();
    //  }
    //  d3.select("#btnFullscreen").attr("src", "fullscreen.png")
    //}

    if (!document['fullscreenElement'] && !document['mozFullScreenElement'] &&
      !document['webkitFullscreenElement'] && !document['msFullscreenElement']) {
      let methodToBeInvoked = elem.requestFullscreen ||
        elem['webkitRequestFullScreen'] || elem['mozRequestFullscreen']
        ||
        elem['msRequestFullscreen'];
      //console.log(methodToBeInvoked);
      if (methodToBeInvoked) {
        methodToBeInvoked.call(elem);
        d3.select("#btnFullscreen").attr("src", "../../assets/images/fullscreen_exit.png")
      }
    }
    else {
      try {
        if (document.exitFullscreen) {
          document.exitFullscreen();
        } else if (elem['msExitFullscreen'] || elem['mozCancelFullScreen'] || elem['webkitExitFullscreen']) {
          let methodToBeInvoked = elem['exitFullscreen'] || elem['webkitRequestFullScreen'] || elem['mozRequestFullscreen'] || elem['msRequestFullscreen']
          methodToBeInvoked.call(elem);
        }
      } catch (e) { console.log(e); }
      d3.select("#btnFullscreen").attr("src", "../../assets/images/fullscreen.png")
    }


  }

  ngAfterViewInit() {
    this.ChartCreate();
  }
}
