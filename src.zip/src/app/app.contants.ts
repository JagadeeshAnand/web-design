export let appContants = {
    outlets: ['menupopup', 'sidemenupopup']
};
