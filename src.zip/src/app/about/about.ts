import { Component, AfterViewInit, ViewEncapsulation } from '@angular/core'; 
declare var jQuery: any;
@Component({
  selector: 'about', 
  templateUrl: './about.html',
  styleUrls: ['./about.css']
})
export class AboutComponent {
  public scrollbarOptions = { axis: 'y', theme: 'minimal-dark', scrollInertia: 300 };
}
